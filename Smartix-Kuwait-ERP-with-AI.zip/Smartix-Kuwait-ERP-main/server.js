/* =========================================================
   Qivenza Server
   - Serves the dashboard (index.html, style.css, script.js)
   - Provides /api/ai endpoint that calls Claude (Anthropic API)
     for real AI answers, using the key from .env
   ========================================================= */

const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");

/* ---------- Load .env (no extra packages needed) ---------- */
function loadEnv() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;

  const lines = fs.readFileSync(envPath, "utf-8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}
loadEnv();

const PORT = process.env.PORT || 5000;
const API_KEY = process.env.ANTHROPIC_API_KEY || "";
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-5";

const MIME_TYPES = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "application/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
};

/* ---------- Call Claude (Anthropic API) ---------- */
async function askClaude(question, products) {
  const productSummary = (products || [])
    .map((p) => `- ${p.name}: sold ${p.sales}, in stock ${p.stock}`)
    .join("\n") || "(no products added yet)";

  const systemPrompt =
    "You are Qivenza AI, a helpful assistant built into a small business " +
    "inventory & sales dashboard (Qivenza) used in Kuwait. Answer briefly " +
    "(2-4 sentences), practically, and in a friendly tone. Use the store's " +
    "real data below when relevant.\n\nCurrent store data:\n" + productSummary;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 400,
      system: systemPrompt,
      messages: [{ role: "user", content: question }],
    }),
  });

  const data = await response.json();

  if (data.error) {
    throw new Error(data.error.message || "Unknown API error");
  }

  const text = (data.content || [])
    .map((block) => block.text || "")
    .join("\n")
    .trim();

  return text || "Sorry, I couldn't generate a response.";
}

/* ---------- HTTP Server ---------- */
const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url, true);

  /* ----- AI endpoint ----- */
  if (req.method === "POST" && parsed.pathname === "/api/ai") {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", async () => {
      res.setHeader("Content-Type", "application/json");

      let question = "";
      let products = [];
      try {
        const parsedBody = JSON.parse(body || "{}");
        question = parsedBody.question || "";
        products = parsedBody.products || [];
      } catch {
        res.writeHead(400);
        res.end(JSON.stringify({ answer: "⚠ Invalid request." }));
        return;
      }

      if (!API_KEY) {
        res.writeHead(200);
        res.end(
          JSON.stringify({
            answer:
              "⚠ Real AI is not set up yet. Open the .env file in this folder " +
              "and add your ANTHROPIC_API_KEY (see README.md for steps).",
          })
        );
        return;
      }

      try {
        const answer = await askClaude(question, products);
        res.writeHead(200);
        res.end(JSON.stringify({ answer }));
      } catch (err) {
        res.writeHead(200);
        res.end(JSON.stringify({ answer: "⚠ AI error: " + err.message }));
      }
    });
    return;
  }

  /* ----- Static file serving ----- */
  let filePath = parsed.pathname === "/" ? "/index.html" : parsed.pathname;
  filePath = path.join(__dirname, filePath);

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("404 Not Found");
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME_TYPES[ext] || "application/octet-stream" });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`Qivenza server running at http://localhost:${PORT}`);
  if (API_KEY) {
    console.log("✅ Real AI (Claude) is enabled.");
  } else {
    console.log("⚠ Real AI not configured — Smart Assistant will still work.");
    console.log("  Add ANTHROPIC_API_KEY in the .env file to enable Real AI.");
  }
});
