/* ===== Qivenza Dashboard Logic ===== */

const STORAGE_KEY = "qivenza_products";
const LOW_STOCK_THRESHOLD = 5;

let products = [];
let editingId = null;

let output = document.getElementById("output");

/* ---------- Storage ---------- */
function saveToStorage() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}

async function loadFromStorage() {
  let saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    products = JSON.parse(saved);
    return;
  }

  try {
    let response = await fetch("./products.json");
    let masterList = await response.json();
    products = masterList;
    saveToStorage();
  } catch (err) {
    products = [
      { id: 1, name: "Charger", sales: 22, stock: 15 },
      { id: 2, name: "Speaker", sales: 9, stock: 4 },
      { id: 3, name: "Cable", sales: 30, stock: 20 },
      { id: 4, name: "Mouse", sales: 0, stock: 2 }
    ];
    saveToStorage();
  }
}

/* ---------- Helpers ---------- */
function getCategory(total) {
  if (total === 0) {
    return "Non-Moving";
  } else if (total < 10) {
    return "Slow Moving";
  } else {
    return "Fast Moving";
  }
}

function getNextId() {
  return products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
}

/* ---------- Render ---------- */
function renderProducts() {
  let searchTerm = document.getElementById("searchBox").value.toLowerCase();
  let filtered = products.filter(p => p.name.toLowerCase().includes(searchTerm));

  output.innerHTML = "";

  if (filtered.length === 0) {
    output.innerHTML = "<div class='empty-state'>No products found.</div>";
  }

  filtered.forEach(p => {
    let category = getCategory(p.sales);
    let isLow = p.stock <= LOW_STOCK_THRESHOLD;

    let row = document.createElement("div");
    row.className = "product-row" + (isLow ? " low-stock" : "");
    row.innerHTML =
      "<div class='product-info'>" +
        "<b>" + p.name + "</b>" +
        "<span class='meta'>Sales: " + p.sales + " • Stock: " + p.stock + "</span>" +
        "<span class='tag'>" + category + "</span>" +
        (isLow ? "<span class='low-badge'>⚠ Low Stock</span>" : "") +
      "</div>" +
      "<div class='product-actions'>" +
        "<button class='icon-btn edit-btn' onclick='startEdit(" + p.id + ")'>✏️</button>" +
        "<button class='icon-btn delete-btn' onclick='deleteProduct(" + p.id + ")'>🗑️</button>" +
      "</div>";

    output.appendChild(row);
  });

  updateStats();
}

function updateStats() {
  document.getElementById("totalProducts").textContent = products.length;
  document.getElementById("totalSales").textContent = products.reduce((sum, p) => sum + Number(p.sales), 0);
  document.getElementById("lowStockCount").textContent = products.filter(p => p.stock <= LOW_STOCK_THRESHOLD).length;
}

/* ---------- Add / Edit / Delete ---------- */
function addProduct() {
  let nameInput = document.getElementById("productName");
  let salesInput = document.getElementById("productSales");
  let stockInput = document.getElementById("productStock");

  let name = nameInput.value.trim();
  let saleQty = Number(salesInput.value) || 0;
  let stockQty = Number(stockInput.value) || 0;

  if (!name) {
    alert("Please enter a product name.");
    return;
  }

  if (editingId !== null) {
    let product = products.find(p => p.id === editingId);
    product.name = name;
    product.sales = saleQty;
    product.stock = stockQty;
    editingId = null;
    document.getElementById("submitBtn").textContent = "Add Product";
    document.getElementById("cancelEditBtn").style.display = "none";
  } else {
    products.push({ id: getNextId(), name: name, sales: saleQty, stock: stockQty });
  }

  nameInput.value = "";
  salesInput.value = "";
  stockInput.value = "";

  saveToStorage();
  renderProducts();
}

function startEdit(id) {
  let product = products.find(p => p.id === id);
  if (!product) return;

  document.getElementById("productName").value = product.name;
  document.getElementById("productSales").value = product.sales;
  document.getElementById("productStock").value = product.stock;

  editingId = id;
  document.getElementById("submitBtn").textContent = "Save Changes";
  document.getElementById("cancelEditBtn").style.display = "inline-block";

  document.getElementById("productName").focus();
}

function cancelEdit() {
  editingId = null;
  document.getElementById("productName").value = "";
  document.getElementById("productSales").value = "";
  document.getElementById("productStock").value = "";
  document.getElementById("submitBtn").textContent = "Add Product";
  document.getElementById("cancelEditBtn").style.display = "none";
}

function deleteProduct(id) {
  if (!confirm("Delete this product?")) return;
  products = products.filter(p => p.id !== id);
  saveToStorage();
  renderProducts();
}

/* ---------- Init ---------- */
async function init() {
  await loadFromStorage();
  renderProducts();
}
init();

window.addProduct = addProduct;
window.startEdit = startEdit;
window.cancelEdit = cancelEdit;
window.deleteProduct = deleteProduct;
window.renderProducts = renderProducts;
/* =========================================================
   Qivenza AI — Smart Assistant (offline, instant, real data)
   + Real AI fallback (Claude, via backend /api/ai)
   ========================================================= */

/* ---------- Smart Assistant: answers from real store data ---------- */
function getSmartAnswer(question) {
  const q = question.toLowerCase();

  if (products.length === 0 && (q.includes("stock") || q.includes("sales") || q.includes("product"))) {
    return "📦 You haven't added any products yet. Add some from the form above first.";
  }

  if (q.includes("low stock") || q.includes("kam stock") || q.includes("running out")) {
    const low = products.filter((p) => p.stock <= LOW_STOCK_THRESHOLD);
    if (low.length === 0) return "✅ No products are low on stock right now.";
    return "⚠ Low stock items: " + low.map((p) => `${p.name} (${p.stock} left)`).join(", ");
  }

  if (q.includes("best sell") || q.includes("top sell") || q.includes("top product")) {
    if (products.length === 0) return "No products added yet.";
    const top = [...products].sort((a, b) => b.sales - a.sales)[0];
    return `🏆 Best selling product: ${top.name} (${top.sales} sold)`;
  }

  if (q.includes("non-moving") || q.includes("non moving") || q.includes("dead stock") || q.includes("not selling")) {
    const dead = products.filter((p) => Number(p.sales) === 0);
    if (dead.length === 0) return "✅ No non-moving products right now.";
    return "🐌 Non-moving products: " + dead.map((p) => p.name).join(", ");
  }

  if (q.includes("slow moving")) {
    const slow = products.filter((p) => Number(p.sales) > 0 && Number(p.sales) < 10);
    if (slow.length === 0) return "No slow-moving products right now.";
    return "🐢 Slow-moving products: " + slow.map((p) => p.name).join(", ");
  }

  if (q.includes("total sales")) {
    const total = products.reduce((sum, p) => sum + Number(p.sales), 0);
    return `💰 Total sales across all products: ${total} units`;
  }

  if (q.includes("total stock") || q.includes("stock level") || q.includes("how much stock")) {
    const total = products.reduce((sum, p) => sum + Number(p.stock), 0);
    return `📦 Total stock across all products: ${total} units`;
  }

  if (q.includes("total product") || q.includes("how many product")) {
    return `📱 You currently have ${products.length} products in Qivenza.`;
  }

  return null; // no local match — let Real AI (Claude) handle it
}

/* ---------- Real AI (free, via Puter.js — no API key, no cost) ---------- */
async function askRealAI(question) {
  if (typeof puter === "undefined" || !puter.ai) {
    return "⚠ Free AI didn't load. Check your internet connection and reload the page.";
  }

  const productSummary =
    products
      .map((p) => `${p.name}: sold ${p.sales}, stock ${p.stock}`)
      .join("; ") || "no products added yet";

  const prompt =
    "You are Qivenza AI, a helpful assistant inside a small business " +
    "inventory & sales dashboard used in Kuwait. Answer briefly (2-4 " +
    "sentences), practically, and in a friendly tone.\n\n" +
    "Current store data: " + productSummary + "\n\n" +
    "Question: " + question;

  try {
    const response = await puter.ai.chat(prompt);
    // puter.ai.chat can return a string or an object depending on version
    if (typeof response === "string") return response;
    return response?.message?.content || response?.text || "Sorry, no response.";
  } catch (err) {
    return "⚠ Free AI error: " + err.message;
  }
}

/* ---------- Shared: get an answer, trying Smart Assistant first ---------- */
async function getQivenzaAnswer(question) {
  const smart = getSmartAnswer(question);
  if (smart) return smart;

  return await askRealAI(question);
}

/* ---------- Header AI button (quick prompt popup) ---------- */
const aiChatBtn = document.getElementById("aiChatBtn");

if (aiChatBtn) {
  aiChatBtn.addEventListener("click", async function () {
    const question = prompt("🤖 Welcome to Qivenza AI\n\nAsk your business question:");
    if (!question) return;

    alert("🤖 Thinking...");
    const answer = await getQivenzaAnswer(question);
    alert("🤖 " + answer);
  });
}

/* ---------- AI Chat box (main panel) ---------- */
const askAI = document.getElementById("askAI");

if (askAI) {
  askAI.onclick = async function () {
    const questionInput = document.getElementById("aiQuestion");
    const question = questionInput.value.trim();
    const aiAnswer = document.getElementById("aiAnswer");

    if (!question) {
      aiAnswer.innerHTML = "🤖 Please type a question first.";
      return;
    }

    aiAnswer.innerHTML = "🤖 Thinking...";
    const answer = await getQivenzaAnswer(question);
    aiAnswer.innerHTML = "🤖 " + answer;
  };
}
