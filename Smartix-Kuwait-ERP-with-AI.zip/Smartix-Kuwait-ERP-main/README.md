# Qivenza
AI Sales, Inventory, Stock and Promotion Management System for Kuwait

## Qivenza AI — 2 Brains in 1 (both free, no setup)

1. **Smart Assistant** — answers instantly using your real product data:
   low stock, best seller, non-moving items, total sales, total stock, etc.
2. **Free Real AI** (powered by Puter.js) — answers any general business
   question in natural language. No API key, no payment, no backend needed —
   it runs straight in the browser and each visitor uses their own free quota.

Note: Puter.js is a free third-party AI gateway, not an official Anthropic
product. It's great for personal/small business use with no cost, but if you
ever want your own private, dedicated AI (e.g. for a bigger business), you
can switch to a paid Anthropic API key instead — see "Optional: Use Your Own
Paid AI Key" below.

## How to Run

1. Make sure Node.js is installed (check with `node -v` in a terminal).
2. Open a terminal inside this folder.
3. Run:
   ```
   node server.js
   ```
4. Open your browser at: `http://localhost:5000`

That's it — both the Smart Assistant and the free Real AI work immediately,
no extra setup needed.

## Optional: Use Your Own Paid AI Key (Anthropic/Claude)

If you'd rather use your own private Anthropic API key instead of the free
shared one:

1. Go to **https://platform.claude.com**, sign up, and add a payment method.
2. Create an API key (starts with `sk-ant-...`).
3. Copy `.env.example` in this folder, rename the copy to `.env`.
4. Open `.env` and paste your key:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
   ```
5. Restart the server (`Ctrl+C`, then `node server.js` again).

This is completely optional — the app works fully without it.
